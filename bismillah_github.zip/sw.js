const CACHE = 'bfarm-v8';
self.addEventListener('install', e => { self.skipWaiting(); });
self.addEventListener('activate', e => { self.clients.claim(); });
self.addEventListener('fetch', e => {
  e.respondWith(
    caches.open(CACHE).then(cache =>
      fetch(e.request).then(r => { cache.put(e.request, r.clone()); return r; })
      .catch(() => caches.match(e.request))
    )
  );
});
